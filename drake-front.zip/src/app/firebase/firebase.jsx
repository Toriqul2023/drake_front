import { initializeApp } from "firebase/app";
export const firebaseConfig = {
    apiKey: "AIzaSyAYoc2Ce2GnoImbZCt4yeOEwzE7RJ30BMw",
    authDomain: "nfc24-e71b4.firebaseapp.com",
    projectId: "nfc24-e71b4",
    storageBucket: "nfc24-e71b4.firebasestorage.app",
    messagingSenderId: "427065559259",
    appId: "1:427065559259:web:b315185aab57358f52e4fe",
    measurementId: "G-78TGFCYRSQ"
  };


 export  const app = initializeApp(firebaseConfig);